# TradingKit Pro

Unpack the ZIP before configuring a supported local/repository marketplace. Point its local source at this plugin directory (the directory containing `plugin.json`, `mcp.json` and `skills/`), then install/enable it in the supported client and start a new conversation. Downloading a ZIP alone is not an installation. The source-repository templates must first be built for the actual deployment.

## Codex private package and connection

Use the supported private ZIP import or a built local/repository marketplace. For an existing private plugin, update its verified account record through the supported update flow; retain its identity and audience. After saving, refresh Personal/My plugins and install or enable that existing entry in Codex. Saving an account release is separate from local installation and OAuth. For a marketplace install, reload through the client after changing its source; do not edit cached files.

If Add plugin reports a generic failure, retain the exact ZIP/version/checksum and inspect the specific upload result. A successful guarded update is evidence that the archive was accepted on that path; it does not establish the cause of an Add plugin error. Do not repeatedly create replacements or change the package name to bypass the error.

When skills appear but tools do not, inspect the installed version, connection enablement and native startup/authentication error. An authentication-required error needs the client's OAuth flow; other missing-tool failures need their own diagnosis. A website login or package upload does not connect this chat. After installation and sign-in, verify `get_account` and `open_workspace` in a fresh chat. A managed plugin server may not appear in the plain CLI's global MCP list; use that plugin's supported connection controls rather than adding a duplicate global server.

For ChatGPT remote MCP testing, turn on Developer mode under Settings → Security and login if available, open Plugins, select the plus button and create the connection using `https://app.tradingkit.com/mcp/pro`. Complete the host OAuth flow for your existing TradingKit account and enable the connection in a new conversation. This tests the server; separately install the full package to test its skills. Account/workspace policy can restrict these surfaces. No universal website import URL or automatic updates are claimed.

The protected OAuth resource/audience is `https://app.tradingkit.com/mcp` for every endpoint alias. Authentication is host-managed; never paste access tokens or secrets into chat/manifests. Installing the TradingKit Pro package never grants membership. Server-side account capabilities control every package.

Compatible hosts may show the compact results widget and one focused workspace/Optimiser; text-only hosts can use returned metrics, job status and exact source exports. Real host sign-in, identity and rendering need acceptance testing. Public-directory availability requires review and approval.

[OpenAI package/local marketplace guide](https://developers.openai.com/plugins/build/plugins) · [Connection and installed-plugin testing](https://developers.openai.com/plugins/deploy/connect-chatgpt)
